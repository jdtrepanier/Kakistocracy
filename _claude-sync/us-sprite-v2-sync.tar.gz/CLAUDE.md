# CLAUDE.md — Kakistocracy: Survive the Term

Instructions for AI coding assistants (and humans) working on this repo.
The full game design is in **[docs/GAME_PLAN.md](docs/GAME_PLAN.md)**. Read the relevant section before building a feature.

## What this is

An isometric satirical political management game for the web, styled like a cozy life-sim (think _The Sims_) rather than a top-down SNES RPG. You play a 4-year term (JAN 2024 → DEC 2027) as a cabinet of 6 officials, spending 3 Executive Actions per month while five national stats (Debt, Interest Rate, Inflation, Party IQ, Happiness) plus DEFCON try to end the run. Survive the term to win. _Shining Force_ is the reference for the screen layout (windows, portraits, cross-shaped menu) — and, for Declare War specifically, for actual turn-based tactical combat too (`engine/battle.ts`, GAME_PLAN §7.1). Every other action still resolves with a plain success roll, no grid involved.

## Commands

The project uses **Yarn 1** (`yarn.lock`). npm also works (`npm start`, `npm run verify`).

| Command           | What it does                                                                   |
| ----------------- | ------------------------------------------------------------------------------ |
| `yarn start`      | Dev server (http://localhost:5173), opens the browser                          |
| `yarn dev`        | Dev server without opening the browser                                         |
| `yarn build`      | Typecheck + production build into `dist/`                                      |
| `yarn preview`    | Serve the production build                                                     |
| `yarn test`       | Run all Vitest tests once                                                      |
| `yarn test:watch` | Tests in watch mode                                                            |
| `yarn typecheck`  | TypeScript only                                                                |
| `yarn lint`       | ESLint                                                                         |
| `yarn format`     | Prettier (write)                                                               |
| `yarn verify`     | **typecheck + lint + format check + tests. Run before calling any task done.** |

Requires Node 22 LTS (see `.nvmrc`; Node ≥ 20.19 works).

## Architecture rules (non-negotiable)

1. **`src/engine/` is pure TypeScript.** No React, no Zustand, no Pixi, no DOM, no `localStorage`. ESLint enforces this.
2. **No `Math.random()` or `Date.now()` in `engine/` or `data/`.** Use `createRng()` from `engine/rng.ts` (seeded, so runs are replayable) and the in-game calendar from `engine/calendar.ts`.
3. **Engine functions are pure:** take a state, return a new state. Never mutate `GameState`.
4. **Content is data.** Actions, characters, events, showdowns, rooms and endings live in `src/data/`. The engine interprets them.
5. **No magic numbers in the engine.** Every tunable value goes in `src/data/balance.ts`.
6. **`src/store/gameStore.ts` is the only bridge** between React and the engine. Components read from the store and call its actions; store actions call engine functions.
7. **No hard-coded UI text.** Add a key to `src/i18n/en.ts` _and_ `src/i18n/fr.ts` (TypeScript fails if French is missing a key), then use `const t = useT()` and `t('key')`.
8. **Character names only come from `src/data/characters.ts`** (the name layer, real vs. parody names). Never type a character's name in a component or string.
9. **Every engine change comes with Vitest tests**, colocated as `*.test.ts`.

## Layout

```text
src/
├─ engine/    pure game rules (calendar, rng, state; economy, effects, actions, endings, movement…)
├─ data/      content + balance numbers (actions, characters, countries, rooms, roomLayouts…)
├─ store/     Zustand store: the bridge
├─ i18n/      en.ts (source of keys), fr.ts, translate.ts
├─ ui/        React components (hud/, room/, menus/, dialogue/, screens/) + hooks
├─ styles/    global.css imports the other CSS files
├─ App.tsx    stage + screens
└─ main.tsx   entry point
public/assets/   sprites, tilesets, Tiled maps, audio
scripts/         Node scripts (balance simulator in Phase 1)
docs/            GAME_PLAN.md
```

Import with the `@/` alias (`@/engine/calendar`), relative imports inside the same folder are fine.

## Conventions

- TypeScript strict mode with `noUncheckedIndexedAccess`. No `any`; prefer `unknown` + narrowing.
- Named exports only (no default exports).
- Files: `camelCase.ts` for modules, `PascalCase.tsx` for components, tests next to the code (`calendar.test.ts`).
- Type-only imports use `import type`.
- Formatting is Prettier's job (single quotes, trailing commas, 100 columns). Don't hand-format.
- Commit messages: short imperative summary (`Add monthly economy tick`).
- Add dependencies with `yarn add` (or `yarn add -D` for tools), and ask before adding one. Current runtime deps: react, react-dom, zustand, @fontsource/press-start-2p.

## Pixel art and screen rules

- Internal resolution **480×270**, scaled up with whole-number zoom (`ui/useStageScale.ts`).
- Rooms are **isometric** (2:1 dimetric), not a flat top-down grid: `ui/room/isometric.ts` projects a room-grid `{x, y}` position to a diamond footprint **32px wide × 16px tall**; walls and objects are extruded blocks (`clip-path`-based, no new dependency). `engine/movement.ts` and `data/roomLayouts.ts` still describe rooms as a plain rectangular grid — only the rendering layer projects that grid isometrically, so a real PixiJS isometric renderer later only touches `ui/room/`.
- Font: Press Start 2P at **8px** (or 16px for titles). One character = 8px wide: count characters when laying out the HUD.
- Short names must fit in 8 characters.
- The 6 US officials and Canada's battle roster use real 4-direction pixel-art sprites (`public/assets/sprites/`, wired via `data/characters.ts`'s `sprite`/`spriteForDirection` and `data/battleRosters.ts`'s `sprite` field on `BattleUnitTemplate`). Every other character (other countries' rosters) still falls back to a coloured square with initials (`placeholder` in `data/characters.ts` / `battleRosters.ts`).

## Tone guardrails (docs/GAME_PLAN.md §14)

- Satirize public actions and policies, not bodies, families or private lives.
- No invented quotes that could pass for real statements. Parody must be obviously parody.
- Cartoon disasters only: wars and meltdowns are gags, maps and headlines, never casualties.
- Opponents, media and bureaucrats get roasted too.

## Status

- [x] **Phase 0 — Setup:** Vite + React + TS, ESLint (with engine guard), Prettier, Vitest, folder structure, name layer, EN/FR strings, seeded RNG, calendar, placeholder title screen + HUD.
- [x] **Phase 1 — "Spreadsheet" prototype:**
  - `engine/effects.ts`: effect DSL (`delta`/`spread`/`delayed`/`chance`/`flag`/`rage`) + delayed-effect queue (`tickPending`)
  - `engine/economy.ts`: month-end tick (§6 formulas, constants from `balance.ts`), DEFCON calm-recovery, Congress/midterms/impeachment tracking
  - `engine/actions.ts` + `engine/resolve.ts`: availability rules (3 EA/month, once-per-month safe actions, IQ gates), success %, success/backfire, diminishing-returns Headlines. _One-action-per-official is deferred to Phase 2_, since there's no character-selection UI yet.
  - `engine/endings.ts`: all loss endings (bankruptcy, hyperinflation, brainFreeze, revolt, nuclear, impeachment) + survival at DEC 2027, with fixed precedence
  - `engine/scoring.ts`: Headlines → rank
  - `data/actions.ts`: 17 actions from §9
  - UI: action list with success %, End Month button, month-end report, ending screens, all EN/FR strings
  - `scripts/simulate.test.ts`: Monte Carlo balance simulator (3000 runs × random/cautious policy) — also asserts survival-rate bounds as a regression guard, run via `yarn simulate`
  - Typecheck, lint and format all verified clean on the real toolchain. **`yarn test` / `yarn verify` / `yarn simulate` still need to be run on a native Windows or macOS/Linux shell** — the assistant's device-bridge shell is a Linux VM whose mounted `node_modules` only has Windows-native Rollup bindings (`@rollup/rollup-win32-*`, no `@rollup/rollup-linux-x64-gnu`) and no network access to fetch the missing one, so Vitest can't execute from there. Run `yarn verify` yourself once from a normal terminal to confirm the suite passes.
- [x] **Phase 2 — Room slice:**
  - `engine/movement.ts`: pure grid movement/collision (`isWalkable`, `moveWithin`) — data in, position out, so the CSS/DOM renderer below can be swapped for real PixiJS/Tiled later without touching it
  - `data/roomLayouts.ts`: Oval Office + Treasury as ASCII-grid tile layouts, one action-bound object each, a door connecting them
  - `data/countries.ts` + new `declareWar`/`purchaseCountry` effects: **World Map menu** — Declare War / Buy a Country each pick a random not-yet-hit country (Canada, Greenland, Panama, Mexico) via the seeded RNG; `GameState` tracks `atWarWith`/`countriesOwned`
  - UI: `RoomView` (CSS/DOM tile grid — see the isometric pivot below, arrow-key/WASD movement, facing + object hint), `OfficialWindow` + `RoomWindow` (§11's info boxes), `CrossMenu` (DECREE/TALK/ITEM/SWITCH), `MapScreen` (world status board), `ActionsOverlay` (DECREE = room-scoped actions, and a toolbar "Executive Actions" escape hatch to the full catalog so nothing is lost while only 2 of 10 rooms exist), TALK/ITEM stubs for Phase 3/5
  - Switching between 3 officials (Trump, Bessent, Vance) — one shared party position for now; per-official positions are a later refinement
  - Typecheck, lint and format verified clean on the real toolchain (same Linux-VM Rollup blocker as Phase 1 for actually running the suite — see above)
- [x] **Phase 3 — Resolution & showdowns:**
  - `engine/preview.ts`: pure `summarizeEffects` — walks an action's effect list into an immediate/over-time stat summary for the Preview window (recurses into `chance`'s `then` branch, flags `hasChance` and `hasRandomCountry`, ignores `flag`/`rage`)
  - `engine/showdown.ts` + `data/showdowns.ts`: showdown DSL (3 rounds × 3 dialogue choices, each choice a success-chance modifier) — two showdowns, **Fed** (paired with Lower Interest Rates) and **Press Conference** (paired with a new `press_conference` action, action #18/§9 row 33, since none existed to pair with a second showdown)
  - `engine/resolve.ts`: `computeSuccessChance`/`resolveAction` gained a backward-compatible `successModifier` parameter so a showdown's total modifier reaches the actual roll, not just the preview display
  - `store/gameStore.ts`: `performAction` replaced by a `resolution` state machine — `beginAction` → (`showdown` rounds, only for the 2 paired actions) → `preview` (confirm/cancel) → roll → `result` (revealed after a brief delay) → `continueResolution` applies the state and logs it, same as the old month report
  - UI: `ResolutionOverlay` renders all three phases (showdown dialogue, preview with success % and stat-delta list, delayed roll reveal with headline flavor text and a stat-diff table matching the month-end report's style)
  - Typecheck, lint and format verified clean on the real toolchain (same Linux-VM Rollup blocker as Phase 1/2 for actually running `yarn test`/`verify`/`simulate` — see above)
- [x] **Art direction pivot — isometric room camera (pre-Phase 4):** dropped the flat top-down 16-bit grid for a 2:1 isometric ("dimetric") camera, closer to _The Sims_' dollhouse view (see GAME_PLAN v0.3's changelog and §11).
  - `ui/room/isometric.ts` (new, pure, tested): `projectIso`/`isoGridBounds`/`projectIsoWithin` turn a grid `{x, y}` into a diamond-projected screen point; `isoDepth` gives painter's-algorithm draw order; `buildCubeFaces` builds the three `clip-path` polygons (top/left/right) for an extruded wall or object block
  - `ui/room/RoomView.tsx`: fully rewritten to render floor/door tiles as flat diamonds and walls/objects as extruded blocks, with a camera (`ui/room/useElementSize.ts` measures the viewport) that follows the player, translating a `room-iso-world` container instead of the old fixed 1:1 tile grid
  - `engine/movement.ts` and `data/roomLayouts.ts` are **untouched** — rooms are still plain rectangular grids; only the rendering layer reinterprets them isometrically, so a future real PixiJS isometric renderer only touches `ui/room/`
  - HUD chrome, the pixel font, and menu conventions are unchanged for now — this pivot is scoped to the room camera only; a broader UI restyle is a possible later art pass, not part of this change
  - i18n: `game.subtitle` (EN/FR) no longer says "16-bit"
  - Typecheck, lint and format verified clean on the real toolchain (same Linux-VM Rollup blocker as above for actually running the suite)
- [x] **Pivot — Tactical battles for Declare War (pre-Phase 4):** Declare War now plays out as a _Shining Force_-style turn-based battle instead of an instant roll (GAME_PLAN §7.1); battle outcome (`usWin`/`enemyWin`) directly drives the action's success/fail effects.
  - `engine/battle.ts` (new, pure, tested): grid, interleaved turn order, BFS `reachableTiles`, `moveUnit`/`attack`/`endTurn`, a simple `enemyTakeTurn` AI, `checkOutcome`
  - `data/battlefield.ts` (new): the fixed battlefield grid + US/enemy spawn points
  - `data/battleRosters.ts` (new): `US_BATTLE_UNITS` (the 3 switchable officials) and `BATTLE_ROSTERS` per country — Canada's roster is the six names requested for this feature (5 real officials + 1 fictional wildcard), Greenland is polar bears; **Iran, Venezuela and Russia (new war-only targets) use invented, non-real-person rosters** rather than real current heads of state, since — unlike the original four — they're in live real-world conflicts (see that file's doc comment)
  - `engine/effects.ts`/`engine/resolve.ts`: `resolveWarEffects` substitutes the battle's actual target country into `declare_war`'s data-declared random-country effect at resolution time; `resolveBattleAction` rolls from the battle's own evolved RNG state, not the pre-battle one (so the battle's moves/attacks aren't replayed)
  - `store/gameStore.ts`: new `battle`/`battleCountry` resolution-phase state, `battleMove`/`battleAttack`/`battleEndTurn`/`battleRunEnemyTurn` actions, `settleBattle` helper
  - `ui/battle/BattleView.tsx` (new): the battle screen, wired into `ResolutionOverlay`'s new `'battle'` phase
  - `data/countries.ts`: added `iran`/`venezuela`/`russia` (war-only, not purchasable)
  - Typecheck, lint and format verified clean on the real toolchain (same Linux-VM Rollup blocker as above for actually running the suite)
- [x] **Phase 4 — Vertical slice:**
  - 3 new rooms + roster/action expansion (22 actions total), all 6 officials playable with their own actions
  - `data/events.ts` + `engine/events.ts`: 20-entry random monthly event system (`rollMonthlyEvent`, weighted, calls `checkEnding`), surfaced in the month-end report and ticker
  - Congress/midterms UI: banners in `MonthEndReport.tsx`, a Congress-lost `HudCell`
  - Save/load: `store/gameStore.ts`'s `SavedGame` (localStorage-backed autosave) + Continue/New Game on the title screen
  - `ui/audio/sfx.ts` + `MuteToggle.tsx`: placeholder Web Audio chiptune blips/jingles/ambient hum, wired in: `App.tsx` runs the ambient hum only on the room/battle screen and mounts `MuteToggle` next to `LangToggle`; `CrossMenu`/`GameScreen`'s toolbar play `blip` (or `confirm` for End Month); `ResolutionOverlay` plays `blip` for showdown choices and the result-continue button, `confirm`/`cancel` for the preview buttons, and `success`/`fail` at the moment a result is revealed; `MonthEndReport` plays `headline` when a new report appears; `EndingScreen` plays `success`/`fail` once when a run ends
  - Real pixel-art sprites for the 6 US officials and Canada's 6-person battle roster (`public/assets/sprites/us/`, `public/assets/sprites/canada/`, cropped from user-provided reference sheets), replacing their coloured-square placeholders on the title screen, room camera, official windows, resolution preview and battle screen — every other country's battle roster is still `placeholder` art
  - Title screen polish: roster in a framed panel with a hover highlight and per-official name-tag color, brief fade-in on load, and `playSfx` on Start/Continue/New Game
  - Typecheck, lint and format verified clean on the real toolchain by syncing to the device via the remote-devices bridge and running `tsc`/`eslint`/`prettier` there (found and fixed two files where hand-predicted Prettier formatting was slightly off). **`yarn test`/`vitest` still can't run from either the assistant's sandbox or the device-bridge shell** — same Linux-VM/Windows-Rollup-binary mismatch as every prior phase; run `yarn verify` yourself from a normal terminal to confirm the suite passes.
- [x] **Art update — US sprite sheet v2 (post–Phase 4):** replaced all 24 US official sprites (`public/assets/sprites/us/`) with a user-supplied transparent-background sheet (`public/assets/sprites/source/us-cabinet-sheet-v2.png`), extracted via an alpha-threshold bounding box (no more white-background ink detection) that also excludes the sheet's baked-in drop shadow so it doesn't double up with `.room-player-shadow`.
  - The new sheet's 4 poses per character are diagonal 3/4 views (front-left/front-right/back-left/back-right), not the old sheet's straight cardinal ones — `data/characters.ts`'s `CharacterSprite` slots are now assigned by which screen diagonal `ui/room/isometric.ts`'s `projectIso` actually draws each `Direction` moving toward (worked out from the projection formula, not guessed), so a character now visibly faces the right way when walking in every direction instead of just approximating it.
  - Canada's roster sprites are untouched (still the original sheet).
- [ ] Phase 5 — Content
- [ ] Phase 6 — Polish & release
